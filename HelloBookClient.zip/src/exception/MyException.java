package exception;

public class MyException extends Exception{
	MyException(){
		super();
	}
	public MyException(String message){
		super(message);
	}
	


}
